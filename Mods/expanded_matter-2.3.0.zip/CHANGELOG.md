
# v2.3.0 - 2023-08-09 - Rare Metals

## Features

* #77 - Allow smelting of crushed metal ores (Thanx Alatyr!)
* #68 - Allow smelting of uranium bits, nuggets and crushed uranium
* #68 - Allow crafting of uranium plates from uranium ingots

## New features

* #72 - Large temporal gears can be crushed into temporal pieces

## Vanilla Tweaks

* #72 - Large temporal gears emit a faint glow
* #68 - Unhide chromium and uranium bits, ingots and plates from handbook

# v2.2.2 - 2023-07-14 - Pigment Fixes

## Bugfixes

* #70 - Fix: malachite nuggets had no pigment anymore

# v2.2.1 - 2023-06-05 - Smelting Fixes

## Bugfixes

* #66 - Crushed ores did not go into the crucible and could thus not be smelted
* #65 - Fix missing handbook entry for zinc oxide
* #65 - Update Japanese translation

# v2.2.0 - 2023-05-24 - More Metals

## Vanilla Tweaks

* #61 - Red dye now made with vermillion (powdered cinnabar) instead of crushed cinnabar

## New features

* #55 - Add manganese oxide (MnO) and manganese dioxide (MnO₂) powder

# v2.1.3 - 2023-05-21 - Hotfixes

## Bugfixes

* #58 - Add Ceramos compatibility: make lead frit craftable again
* #56 - Fix: silver nuggets could not be crushed

# v2.1.2 - 2023-05-18 - Nickel Fixes

## Compatibilitiy with 1.18.3

* #51 - Remove unnec. patches for cupronickel and electrum bits and ingots

## New features

* #52 - Add crushed nickel, nickel bits and ingots can be crushed

# v2.1.1 - 2023-05-09 - Electrum Fixes

## Bugfixes

* #49 - Electrum: fix langkey, ingots and workitems, add plate recipe

# v2.1.0 - 2023-05-08 - Expanded Metals

## Bugfixes

* #33 - Fix: Crushed silver could not be obtained

## Vanilla Tweaks

* #48 - Cupronickel bits can be smelted into ingots
* #48 - Metal parts can be cut into cupronickel bits
* #46 - Electrum bits can be smelted into ingots

## New features

* #46 - Add crushed and powdered electrum
* #27 - Add crushed and powdered graphite

## Balancing

* #33 - Crushing ingots produces 20 crushed pieces

## Translations

* Add some missing language entries
* Fix typos

# v2.0.0 - 2023-04-21 - Powders and Ores

## Vanilla Tweaks

* #36 - Add descriptions to crushed and powdered metals and ores
* #32 - Crushed chromite can be used for tier 3 refractory bricks
* #29 - Dye can be crafted using the new powdered materials
* #26 - Now visible in barrels: powdered borax, powdered sulfur
* #26 - Kernite can be turned into borax
* #17 - Add pigment colors and names for: chromite, anthracite, fluorite
* #1 - Improve handbook entry for: corundum

## Bugfixes

* #43 - Crushed bauxite could not be ground into Powdered bauxite
* #41 - Bone ash visible as fertilizer on farm land
* #40 - Supress handbook entries for non-existing descriptions
* #37 - Handbook entries for crushed items appeared twice
* #33 - Fix: Crushing pentlandite ore yields same amount as crushing nuggets
* #33 - Fix: Impossible to crush some nuggets: cassiterite, chromite, ilmenite

## New features

* #42 - Crushed galena and sphalerite ores can be smelted down
* #39 - Most crushed metals can be smelted down
* #38 - For 1.18: Add crushed and powdered cupronickel
* #26 - Kernite can be turned into borax
* #1 - Add crushed luminous ores: phosphorite, uranium
* #1 - Add crushed luminous metals: uranium
* #1 - Add crushed ores: coal, corundum, galena, granite, hematite, limonite, magnetite, malachite, pentlandite, rhodochrosite, sphalerite
* #1 - Add crushed metals: copper, gold, lead, rusty, silver, tin, titanium, zinc
* #1 - Add powdered luminous ores: fluorite, phosphorite, redphosphorus, whitephoshorus
* #1 - Add powdered ores: bauxite, boneash, cassiterite, cinnabar, chromite, chromiumoxide, coal, corundum, galena, granite, hematite, ilmenite, kernite, lapislazuli, limonite, litharge, leadoxide, magnetite, malachite, massicot, olivine, pentlandite, rhodochrosite, quartz, sphalerite, whitelead, yellowcake, zinc oxide
* #1 - Add powdered metals: copper, gold, lead, nickel, rusty, silver, tin, uranium, zinc

## Translations

* Started Chinese translation
* Started Polish translation
* Started Swedish translation

## Testsuite

* #1 - Testsuite properly handles "skipVariants"
* #1 - Improve testsuite to check for missing handbook entries

# v1.1.2 - 2023-02-19 - Tweaks

## Balancing

* #19 - Increase output of ash-sludge by a factor of two

## Translations

* #24 - Add Japanese translation (Thanx, Macoto Hino!)
* #22 - Add Italian translation (Thanx x_Yota_x & Nahuel-Campos)

# v1.1.1 - 2023-01-30 - Tweaks

## Balancing

* #18 - increase sealing and drying times of ash

# v1.1.0 - 2022-11-13 - Ashes

## New features

* #14 - Add crafting of plant or wood ash and ash sludge. Disabled by default.
* #13 - Add French translation provided by Drakker

# v1.0.1 - 2022-09-18 - First Version

* #10 - Mark glass patches as server-side
* #9 - Add translation to creative tab names, put crushed temporal into Luminous tab

# v1.0.0 - 2022-08-31 - First Version

## New features

* #8 - Add spanish translation by Darce
* #2 - Add crushed temporal pieces and temporal dust
